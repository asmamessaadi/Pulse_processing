#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<thread_pulse_processing.h>


Thread_pulse_processing myThread_for_pulse_processing;
bool pulse_processing_is_done=false;
bool browseF1_is_done=false;
bool browseF2_is_done=false;
bool browseF3_is_done=false;
using namespace std;




MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);



}




void MainWindow::on_browse_scope_data_clicked()
{       QString fileName = QFileDialog::getOpenFileName(this, "Open File",
                                                 QString::null,
                                                 QString::null);

        ui->path_scope_data->setText( fileName );
        this->path_scope_data=fileName;
            browseF1_is_done=true;
}

void MainWindow::on_browse_times_clicked()
{
    QString path;

        path = QFileDialog::getOpenFileName(
            this,
            "Choose a file to open",
            QString::null,
            QString::null);

        ui->path_times->setText( path );
        this->path_times=path;
        browseF2_is_done= true;

}

void MainWindow::on_browse_mvt_timing_clicked()
{
    QString path;

        path = QFileDialog::getOpenFileName(
            this,
            "Choose a file to open",
            QString::null,
            QString::null);

        ui->path_mvt_timing->setText( path );
        this->path_mvt_times=path;
        browseF3_is_done = true;
}

void MainWindow::on_display_clicked()
{
    pulse_vector_wind.clear();
    if(myThread_for_pulse_processing.isFinished()){
        if (myThread_for_pulse_processing.pulse_vector.size()>0)
        {
            for(int i=0;i<myThread_for_pulse_processing.pulse_vector.size();i++){
                pulse_vector_wind.append(myThread_for_pulse_processing.pulse_vector[i]);
            }
            qDebug()<<"We have "<<pulse_vector_wind.size()<<" pulses";


        }
    }

    QVector<double> x,y,x2,y2, x3,y3,x4,y4;

    bool ok;
    bool found=false;
    QVector<int> counts; counts.clear();
    int count=0;
    int s=0;
    QVector<double> pulse_range; pulse_range.clear();
    for(int i=0;i<21;i++){
        pulse_range.append(s);
        s+=50;
        counts.append(0);
    }

    unsigned int num=ui->num_pulse->toPlainText().toLongLong(&ok);
     x.clear();y.clear();x2.clear();;y2.clear(); x3.clear();y3.clear();x4.clear();y4.clear();
    if(pulse_processing_is_done && myThread_for_pulse_processing.isFinished() && ok)
    {   qDebug()<<"start looking for pulse...";

        for(int j=0;j<pulse_vector_wind[0].thresholds.size();j++){
            x3.append(pulse_vector_wind[0].mvt_timing[j]);
            y3.append(pulse_vector_wind[0].thresholds[j]);
        }
        for(int j=0;j<pulse_vector_wind[0].width;j++)
        {
            x4.append(pulse_vector_wind[0].points[j].time);
            y4.append(pulse_vector_wind[0].points[j].voltage);

        }

        for(int i=0;i<pulse_vector_wind.size();i++){
             for(int j=0;j<pulse_range.size()-1;j++){
                 if(pulse_vector_wind[i].peak_value>=pulse_range[j] &&pulse_vector_wind[i].peak_value<=pulse_range[j+1] ){
                     counts[j]++;
                 }
             }

        }

        double sum=0;
        qDebug()<<"----------Pulses range-------";
        for(int i=0;i<pulse_range.size()-1;i++){
            qDebug()<<" range :["<<pulse_range[i] <<"-"<<pulse_range[i+1]<<"] :"<<counts[i]<<"pulses";
            sum+=counts[i];
        }
         qDebug()<<" sum of counts:"<<sum;
         qDebug()<<"---------------------------------";

        for (int i=1;i<pulse_vector_wind.size();i++){

            if (pulse_vector_wind[i].pulse_number==num){
                pulse_vector_wind[i].display_pulse();
                for(int j=0;j<pulse_vector_wind[i].width;j++)
                {
                    x.append(pulse_vector_wind[i].points[j].time);
                    y.append(pulse_vector_wind[i].points[j].voltage);

                }


                for(int j=0;j<pulse_vector_wind[i].thresholds.size();j++){
                    x2.append(pulse_vector_wind[i].mvt_timing[j]);
                    y2.append(pulse_vector_wind[i].thresholds[j]);
                }


                found = true;
                qDebug()<<"Pulse found";
            }

        }

        if(!found){
            qDebug()<<"Error : Pulse not found!!!";
        }
        else
        {
            ui->customPlot->addGraph(); // blue line
            ui->customPlot->graph(0)->setPen(QPen(QColor(40, 110, 255)));
            ui->customPlot->addGraph(); // red line
            ui->customPlot->graph(1)->setPen(QPen(QColor(255, 110, 40)));
            ui->customPlot->axisRect()->setupFullAxesBox();
            ui->customPlot->yAxis->setRange(-1.2, 1.2);
            ui->customPlot->graph(0)->setData(x, y);
            ui->customPlot->graph(1)->setData(x2, y2);
            ui->customPlot->addGraph();
            ui->customPlot->graph(2)->setData(x3, y3);
            ui->customPlot->addGraph();
            ui->customPlot->graph(3)->setData(x4, y4);
            // give the axes some labels:
            ui->customPlot->xAxis->setLabel("x");
            ui->customPlot->yAxis->setLabel("y");
            // set axes ranges, so we see all data:
            ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
            ui->customPlot->graph(0)->rescaleAxes(true);
            ui->customPlot->graph(1)->rescaleAxes(true);
            ui->customPlot->graph(2)->rescaleAxes(true);
            ui->customPlot->graph(3)->rescaleAxes(true);
            ui->customPlot->graph(2)->setPen(QPen(Qt::red));
            ui->customPlot->graph(0)->setPen(QPen(Qt::blue));
            ui->customPlot->graph(1)->setPen(QPen(Qt::green));
            ui->customPlot->graph(3)->setPen(QPen(Qt::black));
            ui->customPlot->replot();
        }
    }
    else if(!pulse_processing_is_done){
        qDebug()<<" Please process data before plotting!!!";
    }
    else if(!myThread_for_pulse_processing.isFinished()){
        qDebug()<<"Please wait.....";
    }
    else if(pulse_vector_wind.size()<num){
        qDebug()<<" Please enter a pulse number less than "<<pulse_vector_wind.size();
    }
    else{
        qDebug()<<" NOTHING IS HERE...";
    }


}

void MainWindow::on_process_clicked()
{   browseF1_is_done = true;
    browseF2_is_done = true;
    browseF3_is_done = true;
    path_scope_data = "/Users/jianghao/Asma/filtered_data_4999.bin";
    path_mvt_times = "/Users/jianghao/Asma/mvt_time.bin";
    path_times = "/Users/jianghao/Asma/time.bin";
    if(browseF1_is_done && browseF2_is_done && browseF3_is_done)
    {
        myThread_for_pulse_processing.processing=false;
        myThread_for_pulse_processing.th_path_mvt_times = path_mvt_times;
        myThread_for_pulse_processing.th_path_times = path_times;
        myThread_for_pulse_processing.th_path_scope_data = path_scope_data;
        myThread_for_pulse_processing.start();
        qDebug()<<" starting pulse processing, please wait....";
        pulse_processing_is_done =myThread_for_pulse_processing.processing;

        qDebug()<< "Pulse processing is done with 0 errors";
        pulse_processing_is_done=true;
    }
    else{
         qDebug()<<" Error in pulse processing";
    }
}
