#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<pulse.h>
#include<iostream>
#include<istream>
#include<fstream>
#include<qdebug.h>
#include<qvector.h>
#include<qcustomplot.h>
//#include<thread_pulse_processing.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    QString path_scope_data;
    QString path_times;
    QString path_mvt_times;
    QVector<Pulse> pulse_vector_wind;

public:
    explicit MainWindow(QWidget *parent = 0);



private slots:
    void on_browse_scope_data_clicked();

    void on_browse_times_clicked();

    void on_browse_mvt_timing_clicked();

    void on_display_clicked();

    void on_process_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
