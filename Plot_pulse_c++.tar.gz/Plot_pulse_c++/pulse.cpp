#include "pulse.h"


Pulse::Pulse()
{
    this->mvt_timing.clear();
    this->peak_position=0;
    this->peak_value =0;
    this->points.clear();
    this->pulse_number=0;
    this->thresholds.clear();
    this->width=0;
    this->thresholds_number=0;

}

void Pulse::init_times()
{

        mvt_setting();
        double sampling = 10.0;
        double time_gap = 1/(sampling*1e9);
        double th_h = 39.978;//max_vector(thresholds);
        double th = 10.07;//min_vector(thresholds);
        // qDebug()<<"th_h"<<th_h;
        //qDebug()<<"th"<<th;
        double th_h_n= nearest_item_in_rise(th_h);
        //qDebug()<<"th_h_n1 : " << th_h_n;
        int num1= position_of_first_given_threshold(th_h_n);
        QVector<double> temp; temp.clear();
        for (int i=0;i<num1;i++){
            temp.append(this->points[i].voltage);
        }
        th_h_n = nearest_item_in_rise(th);
        int num = position_of_first_given_threshold(th_h_n);
        double timepoint;
        timepoint = this->points[num-1].time+time_gap*(th-temp[num-1])/(temp[num-1]-temp[num]);


        QVector<double> tmp; tmp.clear();
        for (int i=0;i<this->width;i++){
            tmp.append(this->points[i].time-timepoint);
        }

        for (int i=0;i<tmp.size();i++){
            this->points[i].time=tmp.at(i);
        }






}

double Pulse::max_vector(QVector<double> v)
{
    double m=v[0];
    if(v.size()!=0){
        for(int i=1;i<v.size();i++){
            if (m<v[i]){
                m=v[i];
            }
        }
    }
    else{
        qDebug ()<< "Error in max_vector function: vector is empty";
    }
    return m;
}

double Pulse::min_vector(QVector<double> v)
{
    double m=v[0];
    if(v.size()!=0){
        for(int i=1;i<v.size();i++){
            if (m>v[i]){
                m=v[i];
            }
        }
    }
    else{
        qDebug ()<< "Error in min_vector function: vector is empty";
    }
    return m;
}

double Pulse::nearest_item_in_rise(double item)
{
    double prev_value =qFabs(item-this->points[0].voltage) ;
    double nearest_value;
    nearest_value = this->points[0].voltage;
    nearest_value = this->points[0].voltage;
    for (int i=0;i<this->peak_position;i++){

        if (qFabs(item-this->points[i].voltage) < prev_value){
            nearest_value = this->points[i].voltage;
            prev_value = qFabs(item-this->points[i].voltage);
        }

}
    return nearest_value;
}

double Pulse::nearest_item_in_decay(double item)
{

    double prev_value =qFabs(item-this->points[peak_position].voltage) ;
    double nearest_value;
    nearest_value = this->points[peak_position].voltage;
    nearest_value = this->points[peak_position].voltage;
    for (int i=this->peak_position;i<this->width;i++){

        if (qFabs(item-this->points[i].voltage) < prev_value){
            nearest_value = this->points[i].voltage;
            prev_value = qFabs(item-this->points[i].voltage);
        }



}
    return nearest_value;
}

int Pulse::position_of_first_given_threshold(double given_th)
{
    for (int i=0;i<this->width;i++){
        if(this->points[i].voltage==given_th){
           return i;
        }
    }
}

void Pulse::mvt_setting()
{
        QVector<double> tmp,tmp2;tmp2.clear(); tmp.clear();
        for(int i=0;i<mvt_timing.size();i++){
            if(mvt_timing[i]!=-100){
                tmp.append(mvt_timing[i]);

            }
        }

        for(int i=0;i<tmp.size()/2;i++){
            tmp2.append(thresholds[i]);
        }
        thresholds.clear();
        for(int i=0;i<tmp2.size();i++){
            thresholds.append(tmp2[i]);
        }
        for(int i=tmp2.size()-1;i>=0;i--){
            thresholds.append(tmp2[i]);
        }

        mvt_timing.clear();
        for(int i=0;i<tmp.size();i++){
            mvt_timing.append(tmp[i]);
        }
        thresholds_number = thresholds.size();

}

void Pulse::display_pulse()
{
    qDebug()<<"--------------------------------------------";
    qDebug()<<"Pulse info: ";
    qDebug()<<"Pulse scope data :";
    qDebug()<<"      Pulse width: "<<width;
    qDebug()<<"      Pulse peak: ("<< this->peak_position<<", "<<this->peak_value<<" )";
    qDebug()<<"      Pulse range: "<<this->pulse_number;
    qDebug()<<"Pulse mvt data :";
    qDebug()<<"      number of thresholds :        "<<thresholds_number;
    qDebug()<<"      Pulse (mvt_timing,threshold) :";
    for(int i=0;i<thresholds.size();i++){
        qDebug()<<"         "<<mvt_timing[i] <<"  "<<thresholds[i];
    }
    qDebug()<<"--------------------------------------------";

}
