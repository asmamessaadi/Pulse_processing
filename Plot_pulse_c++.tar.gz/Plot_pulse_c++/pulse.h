#ifndef PULSE_H
#define PULSE_H
#include <qvector.h>
#include<qdebug.h>
#include<qmath.h>
using namespace std;



struct Point{

    double voltage;
    double time;

};

class Pulse
{

public:
       QVector<struct Point> points;
       int    width;
       double peak_value;
       double peak_position;
       unsigned int pulse_number;
       QVector<double> mvt_timing;
       QVector<double> thresholds;
       int thresholds_number;
       Pulse();
    void init_times();
    double max_vector(QVector<double>v);
    double min_vector(QVector<double>v);
    double nearest_item_in_rise(double item);
    double nearest_item_in_decay(double item);
    int position_of_first_given_threshold(double given_th);
    void mvt_setting();
    void display_pulse();


};



#endif // PULSE_H
