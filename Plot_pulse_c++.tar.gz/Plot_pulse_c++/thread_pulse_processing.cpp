#include "thread_pulse_processing.h"

void Thread_pulse_processing::run()
{
    pulse_vector.clear();
    QVector<double> time_vect;
    time_vect.clear();
    unsigned int number_of_pulse = 2000;
     double elem,elem2;
    ifstream file1(this->th_path_scope_data.toLatin1(), ios::in | ios::binary);
    ifstream file2(this->th_path_times.toLatin1(), ios::in | ios::binary);
    ifstream file3(this->th_path_mvt_times.toLatin1(), ios::in | ios::binary);

    if (!file1 && !file2 && file3) {
        qDebug()<<"Error in opening files";
    }

    else{
        for(int i=0;i<5000;i++){

             file2.read((char*) &elem2, sizeof(double));
             time_vect.append(elem2);

        }
        file1.seekg (0, ios::end);
        //int tam = file1.tellg();
        file1.seekg (0, ios::beg);
        file2.seekg (0, ios::beg);
        file3.seekg (0, ios::beg);

        //qint64 ns = tam/sizeof(float);

        for (unsigned int i=0;i< number_of_pulse; i++){
            Pulse pulse = Pulse();

            for( int ik=0;ik<16;ik++){
                file3.read((char*) &elem, sizeof(double));
                pulse.mvt_timing.append(elem);
            }

            for(int ik = 0; ik < 5000; ik++){

                file1.read((char*) &elem, sizeof(double));

                struct Point po ;

                po.voltage = elem;
                po.time = time_vect[ik];
                if(pulse.peak_value<po.voltage){
                    pulse.peak_value=po.voltage;
                    pulse.peak_position = ik;
                }

                pulse.points.append(po);


            }

            pulse.width=5000;
            pulse.pulse_number= pulse_vector.size()+1;
            pulse.thresholds.append(10.07);pulse.thresholds.append(20.14);pulse.thresholds.append(29.90);pulse.thresholds.append(39.97);
            pulse.thresholds.append(50.04);pulse.thresholds.append(60.11);pulse.thresholds.append(69.88);pulse.thresholds.append(79.95);
            pulse.thresholds.append(79.95);pulse.thresholds.append(69.88);pulse.thresholds.append(60.11);pulse.thresholds.append(50.04);
            pulse.thresholds.append(39.97);pulse.thresholds.append(29.90);pulse.thresholds.append(20.14);pulse.thresholds.append(10.07);
            pulse.init_times();
            pulse_vector.append(pulse);

        }




        qDebug()<<"Thread finished with 0 errors....";


        file1.close();
        file2.close();
        file3.close();
    }
    this->processing = true;

}





Thread_pulse_processing::Thread_pulse_processing()
{
}
