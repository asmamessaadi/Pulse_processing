#ifndef THREAD_PULSE_PROCESSING_H
#define THREAD_PULSE_PROCESSING_H

#include<QThread>
#include<pulse.h>
#include<iostream>
#include<istream>
#include<fstream>
#include<qdebug.h>
#include<qvector.h>


class Thread_pulse_processing :public QThread
{
    public:
   QString th_path_scope_data;
    QString th_path_times;
    QString th_path_mvt_times;
    QVector<Pulse> pulse_vector;
    bool processing;

    void run();
    Thread_pulse_processing();
};

#endif // THREAD_PULSE_PROCESSING_H

